
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="http://webconsultant.co.nz/jslibs/jquery-1.8.1.min.js"><\/script>')</script>

<script src="http://code.jquery.com/ui/1.9.1/jquery-ui.js"></script>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.23/jquery-ui.min.js"></script>-->
<!--<script src="<?php //echo base_url(); ?>js/jquery.cookie.js"></script>-->
<script src="<?php echo base_url(); ?>js/js.js"></script>
</body>
</html>