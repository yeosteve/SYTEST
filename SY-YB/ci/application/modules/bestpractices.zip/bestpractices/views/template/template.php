<?php
$this->load->view('template/header.inc.php'); ?>
<?php $this->load->view($mainContent); ?>
<?php $this->load->view('template/footer.inc.php'); ?>