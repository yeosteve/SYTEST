<?php
/**
 * country/city selector list with Jquery and Codeigniter
 * 
 */


class Countries extends MX_Controller {

    function __construct()
    {
	parent::__construct();
	    exit('FILE: '.__FILE__.'<br />LINE:'.__LINE__);
	//$this->load->library('html_engine');
	//$this->load->model('Countries');
	
	$this->output->enable_profiler(TRUE);
    }

/**
 * page loads with only the country list populated
 * 
 */
    public function index()
	{
	  // get the data for the countries list
	  exit('FILE: '.__FILE__.'<br />LINE:'.__LINE__);
//	    $arrOptions = $this->Countries->countries();
//		// make the dropdown
//	    $data['countryOptions'] =  $this->html_engine->makeOptions($arrOptions);
//	    
//		$data['title'] = 'Country/City selector';
//    	    $this->load->view('includes/startHTML',$data);
//    	    $this->load->view('countries-view',$data);
//    	  //  $this->load->view('teachingOrder');
//    	    $this->load->view('includes/endHTML',$data);
	}
// eof modules/countries/countries.php  17 Sept 2012