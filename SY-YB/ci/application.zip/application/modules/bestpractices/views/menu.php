
<ul>
    <li><a href="/BP/bestpractices/">All Best Practices</a></li>
    <li><a href="/BP/bestpractices/index/1">Best Practices WE01</a></li>
    <li><a href="/BP/bestpractices/index/2">Best Practices WE02</a></li>
    <li><a href="/BP/bestpractices/index/3">Best Practices WE03</a></li>
    <li><a href="/BP/bestpractices/index/4">Best Practices WE04</a></li>
    <li><a href="/BP/bestpractices/index/6">Best Practices WE06</a></li>
    <li id="linkNewBP">New Best Practice </li><!-- call ajax to make form in lightbox-->
    <!--<li><a href="/BP/admin/listBP">Update/Delete Best Practice</a></li>--><!-- call ajax to make list -->
</ul>

