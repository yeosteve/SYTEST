<div id="container">
<?php


/**
 *"Pass"  and "Distinction" should be defined as constants in a config file
 *
 *  Displays all the BPs in order of modules
 *  Requires one array of
 *  $arr[moduleName][categoryName][level][bp1,bp2,...]
 *
 *  foreach(modulename as ModName => categoryArray){
        echo '<h2>moduleName</h2>
        foreach(categoryArray as catName => BParray)
            echo '<h3>catName</h3>
            foreach(catName as level => BPs)
                echo (level == 1)?'Distinction':'Pass;
                $bpList = <ul>
                foreach(BPs as bp){
                    $bpList .= '<li>bp</li>
                }
                $bpList .= </ul>
 }
 *
 */

foreach($stuff as $module => $allTheCategoriesForOneModule){
    echo '<section >'."\n";
    echo '<img src="'.base_url().'img/checkbox15.png" /><h2>';
   echo $module;     // Module name  WE01 etc
   echo '</h2>'."\n";


   foreach($allTheCategoriesForOneModule as $categ=>$value){
    
      echo '<h3>';
      echo $categ;
      echo '</h3>'."\n";
      foreach ($value as $k=>$v){
            echo '<h4>'.$k.'</h4>'."\n";
            
            echo '<ul>'."\n";
            foreach($v as $z =>$bp){
               echo '<li>'.$bp[1].'<div  class="jqupdate" data-uid="'.$bp[0].'">Update</div></li>'."\n";
            }
      echo '</ul>'."\n";
      }
      echo '<br />'."\n";
   }
   echo '</section>'."\n";
}
$this->load->view('menu');
?>

</div>

<div id="cover"><div id="results" style="color:white;font-size:100%;"></div></div>
<div id="formContainer"></div>