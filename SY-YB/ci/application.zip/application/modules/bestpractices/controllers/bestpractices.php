<?php
/**
 *  publicview will control the display of publicly acccessible views
 *
 *  A) List of all in ascending order of modules, each in two lists, regular and distinction, all bullet pointed
 *      a) web view
 *      b) mobile view
 *      c) print view
 *  B) Show selected module, then all previous DESC by module
 *      a) web view with bullet points
 *      b) marking schedule view  -  format for print, desktop and mobile
 *          checkboxes by each best practice for current module
 *          checkboxes by each category for all past modules
 *      
 *  C) Search for one best practice category  - web view only
 *  
 *
 *  models will return arrays of
 *      a selected module
 *          getCategoriesByModule($id) - returns array of categories  $arrBPs[moduleID][catID]  
 *          foreach(category){
 *              $arrBP[moduleID][catID]['regular'] = getBPs($categoryID ,$excel) excel = 0
 *              $arrBP[moduleID][catID]['distinction'] = getBPs($categoryID ,$excel) excel = 1
 *              }
 *      all modules prior to selected in descending order       getAllModules
 *  
 */
class Bestpractices extends CI_Controller{
    
    function __construct()
    {
        parent::__construct();
        $this->load->database('bp');
        $this->load->model('Bpmodel');
    }
    
    function index()

    {
       //exit(__FILE__);
        //$this->output->enable_profiler(TRUE);
        $data['title'] = 'Best Practices';
        
       
        $data['stuff'] = $this->Bpmodel->getSelection();
        $this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Last-Modified: '.gmdate('D, d M Y H:i:s', strtotime('now')).' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        
        $data['mainContent'] = 'bestpractices-view';
        $this->load->view('template/template',$data);
    }
    
    
    function makeList()
    {
        $this->load->model('Bpmodel');
        $data['stuff'] = $this->Bpmodel->getSelection();
        $this->output->set_header("HTTP/1.0 200 OK");
        $this->output->set_header("HTTP/1.1 200 OK");
        $this->output->set_header('Last-Modified: '.gmdate('D, d M Y H:i:s', strtotime('now')).' GMT');
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate");
        $this->output->set_header("Cache-Control: post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        
        //$data['mainContent'] = 'bestpractices-view';
        $this->load->view('bestpractices-view',$data);
        
        
        
    }

}